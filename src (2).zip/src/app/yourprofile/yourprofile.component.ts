import { Component, OnInit, ViewContainerRef, ChangeDetectorRef } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { FormGroup, FormControl, Validators, NgForm, AbstractControl,FormBuilder } from '@angular/forms';
import {AuthService} from '../auth.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
@Component({
  selector: 'app-yourprofile',
  templateUrl: './yourprofile.component.html',
  styleUrls: ['./yourprofile.component.css']
})
export class YourprofileComponent implements OnInit {
  login_form:FormGroup;
  invalidcred: any;
  submitForm: any;
  formGroup = this.fb.group({
    file: [null, Validators.required]
  });
  onFileChange(event) {
    let reader = new FileReader();
   
    if(event.target.files && event.target.files.length) {
      const [file] = event.target.files;
      console.log(file);
      reader.readAsDataURL(file);
    
      reader.onload = () => {
        this.formGroup.patchValue({
          file: reader.result
          
        });
        console.log(file);
        // need to run CD since file load runs outside of zone
        this.cd.markForCheck();
      };
    }
  }
  constructor(private auth:AuthService,private formBuilder: FormBuilder, public toastr: ToastrService, vcr: ViewContainerRef, private http : Http, private router: Router,private fb: FormBuilder, private cd: ChangeDetectorRef) { 
    this.login_form = formBuilder.group({
      fname: ['', Validators.compose([Validators.email, Validators.required])],
      lname: ['', Validators.compose([Validators.email, Validators.required])],
      email: ['', Validators.compose([Validators.email, Validators.required])],
      number: new FormControl (null, [Validators.required,Validators.minLength(6), Validators.maxLength(13)]),
      country: ['', Validators.compose([Validators.email, Validators.required])]
    })
  }

  ngOnInit() {
  }


}
