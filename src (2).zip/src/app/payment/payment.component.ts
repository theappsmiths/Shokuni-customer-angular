import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { FormGroup, FormControl, Validators, NgForm, AbstractControl,FormBuilder } from '@angular/forms';
import {AuthService} from '../auth.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  login_form:FormGroup;
  invalidcred: any;
  submitForm: any;
  constructor(private auth:AuthService,private formBuilder: FormBuilder, public toastr: ToastrService, vcr: ViewContainerRef, private http : Http, private router: Router) { 
    this.login_form = formBuilder.group({
     // cnumber: ['', Validators.compose([Validators.email, Validators.required])],
     // sortcde: ['', Validators.compose([Validators.email, Validators.required])],
      //csv: ['', Validators.compose([Validators.email, Validators.required])],
      cnumber: new FormControl (null, [Validators.required,Validators.minLength(13), Validators.maxLength(13)]),
      sortcde: new FormControl (null, [Validators.required,Validators.minLength(3), Validators.maxLength(13)]),
      csv: new FormControl (null, [Validators.required,Validators.minLength(6), Validators.maxLength(13)]),
      //number: new FormControl (null, [Validators.required,Validators.minLength(6), Validators.maxLength(13)]),
      //country: ['', Validators.compose([Validators.email, Validators.required])]
    })
  }

  ngOnInit() {
  }

}
