import { Component, OnInit } from '@angular/core';

//import { FormGroup, FormControl, Validators, NgForm, AbstractControl } from '@angular/forms';
//import { Router } from '@angular/router';
//import { DashboardComponent } from './dashboard/dashboard.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  //providers: [Router]
})
export class AppComponent implements OnInit {
  
  
  //router: any;
  constructor() {}
  ngOnInit () {
    
    
  }

  /**
   * Method to submit login form
   */
  
}
